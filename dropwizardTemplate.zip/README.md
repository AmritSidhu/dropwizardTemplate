Dropwizard Hello-World template
=====

Purpose
-----
* This is intended to be used as a starting point for developing Dropwizard applications
* it has one endpoint: http://localhost:3000/hello-world

To Run
-----
```
./gradlew run
```

To test
-----
```
./gradlew test
```


